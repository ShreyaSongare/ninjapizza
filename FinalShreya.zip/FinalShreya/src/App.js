import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./Page/Home/Home";
import Section3 from "./Page/Home/Section3";
import Section2 from "./Page/Home/Section2";
import Section6 from "./Page/Home/Section6";
import Section7 from "./Page/Home/Section7";

function App() {
  return (
    
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<Section2 />} />
        <Route path="/menu" element={<Section3 />} />
        <Route path="/blog" element={<Section6/>} />
        <Route path="/contact" element={<Section7 />} />
        
      </Routes>
    </Router>
  );
}

export default App;