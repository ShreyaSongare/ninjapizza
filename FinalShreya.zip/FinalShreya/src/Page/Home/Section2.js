import React from "react";
import { Container, Row, Col} from "react-bootstrap"; // Import Card from bootstrap
import { Link } from "react-router-dom";
import Pizza from "../../assets/hero/about/pizza-slice.png";
import Salad from "../../assets/hero/about/salad1.png";
import Delivery from "../../assets/hero/about/food-delivery.png";

// Sample data for the cards
const mockData = [
  {
    image: Pizza,
    title: "Original Pizza",
    paragraph: `Indulge in our signature pizzas made with the finest ingredients. Each bite is a journey into flavor, crafted to satisfy your taste buds.`,
  },
  {
    image: Salad,
    title: "Quality Fresh Salad",
    paragraph: `Our salads are made with fresh, hand-picked ingredients, giving you a healthy and delicious experience every time.`,
  },
  {
    image: Delivery,
    title: "Fastest Delivery",
    paragraph: `Get your food delivered hot and fresh to your doorstep in no time. Our delivery service ensures you never wait long for a meal.`,
  },
];

function Section2() {
  return (
    <>
      <section className="about_section">
        <Container>
          <Row>
            <Col lg={{ span: 8, offset: 2 }} className="text-center">
              <h2>The burger tastes better when you eat it with your family</h2>
              <p>
                Enjoy a delicious meal with your loved ones! Our food is crafted to bring everyone together with taste, quality, and love.
                <p>
                   our burger is special because it combines falvous texture and endless customization in one sastyfing bite.The juciy seasond patty whether chicken or plant based perfectly with soft tosted bun.
                   Toppings like crisp lettuce, fresh tomatoes, melted cheese, and savory sauces add layers of taste and texture. Each bite offers a balance of richness, crunch, and zest, making it a universally loved comfort food. Whether classic or gourmet, burgers bring people together, offering a delicious, handheld meal that can be enjoyed anytime, anywhere.
                    </p>
                    <p>
                     The smoky, charred flavor of a well-cooked patty combined with melted cheese, crispy bacon, sautéed onions, or tangy pickles creates a mouthwatering experience. Sauces like ketchup, mayonnaise, mustard, or secret house blends further enhance the flavor, making each bite unique. Beyond taste, burgers have a cultural significance, representing comfort, indulgence, and social bonding. Whether grilled at a backyard barbecue, ordered at a diner, or enjoyed as a street food delicacy, a burger is more than just a meal—it’s an experience that brings joy with every bite.
                    </p>
              </p>
              <Link to="/menu" className="btn ">
                Explore Full Menu
              </Link>
            </Col>
          </Row>
        </Container>
      </section>

      <section className="about_wrapper">
        <Container>
          <Row className="justify-content-md-center">
            {mockData.map((cardData, index) => (
              <Col md={6} lg={4} className="mb-4 mb-md-0" key={index}>
               <div className="about_box text-center">
                <div className="about_icon">
                  <img src={cardData.image} className="img-fluid" alt="icon"/>
                </div>
                <h4>{cardData.title}</h4>
                <p>{cardData.paragraph}</p>
               </div>
              </Col>
            ))}
          </Row>
        </Container>
      </section>
    </>
  );
}

export default Section2;
